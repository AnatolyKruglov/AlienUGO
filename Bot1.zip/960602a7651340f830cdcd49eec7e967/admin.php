<?php
    $insert = "";
    //define('TOKEN', '1404472842:AAFNniI1P0Pqc8ePXXiX1pJO9Q0vU2XJ2gg');
    //$data = json_decode(file_get_contents("https://unutolei.ru/f.txt"), TRUE);
    
    $data = explode("+", substr(file_get_contents('php://input'), 5));
    
    $mailing = "";
    for($i = 0; $i < sizeOf($data); $i++) {
        $mailing = $mailing.$data[$i]." ";
    }
    file_put_contents('MAILING.txt', $mailing);
    
    if(file_get_contents('https://unutolei.ru/MAILING.txt') !== " "){
        $insert = "Отправлено недавно: ".file_get_contents('https://unutolei.ru/MAILING.txt');
    }

    //file_get_contents('https://api.telegram.org/bot'.TOKEN."/sendmessage?chat_id=".$data['chat']['id']."&text=".$mailing);
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>AlienUGO_test_bot ADMIN</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </head>

  <body>
    <div class="container">
      <p></p>
      <div class="jumbotron">
        <h1>@AlienUGO_test_bot</h1>
      </div>
      <p></p>
      <div class="jumbotron">
        <h1>Новая рассылка</h1>
        <p></p>
        <form action="https://unutolei.ru/admin.php" method="post">
          <div class="form-group">
            <textarea class="form-control" id="ta" rows="6" name="text" placeholder="<?php echo $insert; ?>" required></textarea>
          </div>

          <button type="submit" class="btn btn-primary" align="right">Отправить</button>


        </form>
      </div>
    </div>
  </body>
</html>
