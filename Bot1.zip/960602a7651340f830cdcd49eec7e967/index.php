<?php

# Принимаем запрос
$data = json_decode(file_get_contents('php://input'), TRUE);
file_put_contents('f.txt', '$data: '.print_r($data, 1)."\n", FILE_APPEND);
//https://api.telegram.org/bot*Токен бота*/setwebhook?url=*ссылка на бота*

# Обрабатываем ручной ввод или нажатие на кнопку
$data = $data['callback_query'] ? $data['callback_query'] : $data['message'];

# Важные константы
define('TOKEN', '1404472842:AAFNniI1P0Pqc8ePXXiX1pJO9Q0vU2XJ2gg');
$menu = ['0' => [
    'resize_keyboard' => true,
    'keyboard' => [
        [
            ['text' => 'О вечеринке'],
            ['text' => 'Сколько стоит'],
        ],
        [
            ['text' => 'Музыка и лайнап'],
            ['text' => 'Дресс-код'],
        ],
        [
            ['text' => 'Пригласить друга'],
            ['text' => 'Получить билеты'],
        ],
        [
            ['text' => 'Остались вопросы'],
        ]
    ]
]
];

$password_verified = false;
$password_status = file_get_contents("https://unutolei.ru/password_status.txt");
if(strpos($password_status, $data['from']['username']) !== false) 
{
    $password_verified = true;
} 

# Записываем сообщение пользователя
$message = mb_strtolower(($data['text'] ? $data['text'] : $data['data']),'utf-8');

if($password_verified == false)
{
    switch($message){
        case "/start":
            $method = 'sendVideo';
            $send_data = [
                'video' => 'https://unutolei.ru/media/welcomeoptimizedminigif.mp4',
                'caption' => file_get_contents("https://unutolei.ru/texts/start.txt")
            ];
            break;
            
        case "password":
            $method = 'sendMessage';
            $send_data = [
                'text' => "Привет, ".$data['from']['first_name']."!\n\n".file_get_contents("https://unutolei.ru/texts/codeCorrect.txt"),
                'reply_markup' => $menu['0']
            ];
            file_put_contents('password_status.txt', $data['from']['username']."\n", FILE_APPEND);
            
            break;
            
        default:
            $method = 'sendMessage';
            $send_data = [
                'text' => file_get_contents("https://unutolei.ru/texts/codeWrong.txt")
            ]; 
            break;
    }
    
} else {



# Обрабатываем сообщение
switch ($message)
{
    case '/start':
        $method = 'sendMessage';
        $send_data = [
            'text' => "Вы уже запустили бот))",
            'reply_markup' => $menu['0']
        ];
        break;

    case '/braslet':
        $method = 'sendMessage';
        $send_data = [
            'text' => file_get_contents("https://unutolei.ru/texts/braslet.txt"),
            'reply_markup' => $menu['0']
        ];
        break;

    case 'о вечеринке':
        $method = 'sendPhoto';
        $send_data = [
            'photo' => 'https://unutolei.ru/media/totibadze.jpg',
            'caption' => file_get_contents("https://unutolei.ru/texts/about.txt"),
            'reply_markup' => $menu['0']
        ];
        break;

    case 'сколько стоит':
        $method = 'sendMessage';
        $send_data = [
            'text' => file_get_contents("https://unutolei.ru/texts/price.txt"),
            'reply_markup' => $menu['0']
        ];
        break;

    case 'музыка и лайнап':
        $method = 'sendPhoto';
        $send_data = [
            'photo' => 'https://unutolei.ru/media/lineup.jpg',
            'caption'  => file_get_contents("https://unutolei.ru/texts/music.txt"),
            'reply_markup' => $menu['0']
        ];
        break;

    case 'дресс-код':
        $method = 'sendMessage';
        $send_data = [
            'text'   => file_get_contents("https://unutolei.ru/texts/dresscode.txt"),
            'reply_markup' => $menu['0']
        ];
        break;

    case 'пригласить друга':
        $method = 'sendMessage';
        $send_data = [
            'text'   => file_get_contents("https://unutolei.ru/texts/invite.txt"),
            'reply_markup' => $menu['0']
        ];
        break;

    case 'получить билеты':
        $method = 'sendMessage';
        $send_data = [
            'text'   => "(проверка по бд)",
            'reply_markup' => $menu['0']
        ];
        break;

    case 'остались вопросы':
        $method = 'sendMessage';
        $send_data = [
            'text'   => file_get_contents("https://unutolei.ru/texts/moreQuestions.txt"),
            'reply_markup' => $menu['0']
        ];
        break;

    default:
        $method = 'sendMessage';
        $send_data = [
            'text' => 'Не понимаю о чем вы :(',
            'reply_markup' => $menu['0']
        ];
}

}
# Добавляем данные пользователя
$send_data['chat_id'] = $data['chat']['id'];
$res = sendTelegram($method, $send_data);

function sendTelegram($method, $data, $headers = [])
{
    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_POST => 1,
        CURLOPT_HEADER => 0,
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_URL => 'https://api.telegram.org/bot' . TOKEN . '/' . $method,
        CURLOPT_POSTFIELDS => json_encode($data),
        CURLOPT_HTTPHEADER => array_merge(array("Content-Type: application/json"), $headers)
    ]);

    $result = curl_exec($curl);
    curl_close($curl);
    return (json_decode($result, 1) ? json_decode($result, 1) : $result);
}